from .image_classification import ImageClassification

__all__ = ['ImageClassification']
